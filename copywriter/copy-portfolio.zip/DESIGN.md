# Design Brief

## Direction

Warm Analog Editorial — refined portfolio landing page with editorial hierarchy, professional warmth, and generous whitespace for copy clarity.

## Tone

Inviting yet authoritative. Warm cream and terracotta tones evoke trust and editorial expertise without corporate coldness.

## Differentiation

Serif display headlines (Lora) paired with clean sans-serif body (DM Sans) creates editorial credibility while minimalist spacing lets portfolio content dominate.

## Color Palette

| Token      | OKLCH         | Role                                |
| ---------- | ------------- | ----------------------------------- |
| background | 0.96 0.015 75 | Warm cream main surface             |
| foreground | 0.2 0.03 50   | Deep terracotta text                |
| primary    | 0.45 0.12 30  | Warm terracotta CTA buttons         |
| accent     | 0.5 0.1 160   | Sage green secondary highlights     |
| muted      | 0.92 0.02 75  | Light cream section backgrounds     |
| card       | 0.98 0.01 75  | White card surfaces                 |

## Typography

- Display: Lora — hero headlines and section headings for editorial authority
- Body: DM Sans — copy, labels, portfolio descriptions for clarity and readability
- Scale: hero 5xl-7xl bold tight, h2 3xl-5xl bold tight, label sm-base semibold, body base-lg regular

## Elevation & Depth

Subtle shadows on cards (shadow-card) lift content from background; generous spacing creates breathing room. No layered complexity — surface hierarchy through background color alternation and delicate shadows.

## Structural Zones

| Zone    | Background  | Border         | Notes                                |
| ------- | ----------- | -------------- | ------------------------------------ |
| Header  | card        | bottom border  | Sticky, minimal nav, brand-forward   |
| Hero    | background  | —              | Full-width, generous padding         |
| Content | background  | —              | Alternating muted/card sections      |
| CTA     | accent/10%  | subtle         | Email link with secondary styling    |
| Footer  | muted       | top border     | Copyright, copyright text centered   |

## Spacing & Rhythm

Generous section gaps (6-8rem vertical), card grouping (1-2rem internal padding), micro-spacing through typography weight variation. Section backgrounds alternate (cream, white, light sage) to create natural rhythm without visual noise.

## Component Patterns

- Buttons: terracotta primary, white text, subtle rounded corners (6px), hover darkens by ~10% lightness
- Cards: white background, subtle bottom border or shadow-card, 1.5rem internal padding, portrait layout
- Portfolio items: card with project title (Lora), description, metrics in a single column

## Motion

- Entrance: fade-in on scroll (smooth cubic timing, 0.3s)
- Hover: button/link opacity increase + slight scale (1.02), smooth transition
- Decorative: none — restraint prioritized over animation

## Constraints

- No gradient backgrounds — solid colors only
- Minimal decoration — let copy shine
- Max 5 key sections per page (hero, portfolio, about, contact, footer)
- Professional tone — no playful elements or emojis

## Signature Detail

Serif display headlines on warm cream background positioned as email copywriting authority — the typography choice itself signals editorial expertise and converts immediately.


