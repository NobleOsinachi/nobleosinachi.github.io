import { ArrowDown, CheckCircle2, Mail } from "lucide-react";
import { motion } from "motion/react";
import { Layout } from "../components/Layout";
import { type Project, ProjectCard } from "../components/ProjectCard";

const PROJECTS: Project[] = [
  {
    title: "Welcome Sequence for SaaS Startup",
    category: "Onboarding Email Series",
    description:
      "Rewrote a 5-email onboarding sequence for a B2B SaaS tool. Shifted from feature-led to outcome-led copy, building trust through early wins and clear next steps.",
    metric: "43%",
    metricLabel: "Open rate",
  },
  {
    title: "Re-engagement Campaign for E-commerce",
    category: "Win-back Campaign",
    description:
      "A 3-email win-back sequence targeting lapsed customers with personalized subject lines and a time-limited incentive. Recovered a significant share of dormant buyers.",
    metric: "18%",
    metricLabel: "Win-back rate",
  },
  {
    title: "Product Launch Email for Health Brand",
    category: "Launch Campaign",
    description:
      "Crafted launch-day and post-launch emails anchored around transformation stories and social proof. Paired emotional hooks with urgency mechanics that drove repeat purchase.",
    metric: "6.2×",
    metricLabel: "ROI",
  },
  {
    title: "Newsletter Redesign for B2B Media",
    category: "Newsletter Strategy",
    description:
      "Restructured format, rewrote tone, and introduced a consistent editorial voice for a B2B newsletter. Higher engagement came from clearer hierarchy and better scanability.",
    metric: "2.1×",
    metricLabel: "Click-through rate",
  },
  {
    title: "Cold Outreach Sequence for Consultancy",
    category: "Outbound Sales Copy",
    description:
      "Wrote a 4-touch cold email sequence for a strategy consultancy targeting mid-market operations teams. Focused on specificity, relevance, and low-friction calls-to-action.",
    metric: "31%",
    metricLabel: "Reply rate",
  },
];

const SKILLS = [
  "Subject line optimization",
  "A/B testing",
  "Conversion copywriting",
  "Drip campaigns & sequences",
  "Audience segmentation",
  "Brand voice development",
];

function scrollTo(id: string) {
  document.querySelector(id)?.scrollIntoView({ behavior: "smooth" });
}

export default function Portfolio() {
  return (
    <Layout>
      {/* ── Hero ─────────────────────────────────────────────────── */}
      <section className="relative bg-background min-h-[calc(100vh-4rem)] flex items-center">
        <div className="max-w-5xl mx-auto px-6 py-24 grid lg:grid-cols-2 gap-12 items-center w-full">
          {/* Copy */}
          <div className="flex flex-col gap-6">
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-xs font-body uppercase tracking-[0.2em] text-primary"
            >
              Email Copywriter & Marketing Strategist
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-display text-5xl lg:text-6xl font-bold text-foreground leading-[1.1] tracking-tight"
            >
              Email Copy That{" "}
              <em className="not-italic text-primary">Converts.</em>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg font-body text-muted-foreground leading-relaxed max-w-lg"
            >
              I write emails people actually want to open — and act on.
              Compelling sequences that nurture leads, boost engagement, and
              drive measurable results for ambitious brands.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-wrap items-center gap-4 pt-2"
            >
              <button
                type="button"
                onClick={() => scrollTo("#work")}
                data-ocid="hero-cta-work"
                className="inline-flex items-center gap-2 bg-primary text-primary-foreground font-body text-sm px-6 py-3 rounded-md hover:opacity-90 transition-smooth shadow-card"
              >
                View Portfolio
                <ArrowDown size={15} />
              </button>
              <a
                href="mailto:hello@yourname.com"
                data-ocid="hero-cta-email"
                className="inline-flex items-center gap-2 font-body text-sm text-muted-foreground hover:text-foreground border border-border px-6 py-3 rounded-md transition-smooth"
              >
                <Mail size={15} />
                hello@yourname.com
              </a>
            </motion.div>
          </div>

          {/* Hero image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="hidden lg:block rounded-xl overflow-hidden shadow-elevated"
          >
            <img
              src="/assets/generated/hero-editorial.dim_1200x700.jpg"
              alt="Abstract editorial composition representing email marketing"
              className="w-full h-auto object-cover"
            />
          </motion.div>
        </div>
      </section>

      {/* ── Portfolio ─────────────────────────────────────────────── */}
      <section id="work" className="bg-muted/30">
        <div className="max-w-5xl mx-auto px-6 py-24">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="mb-12"
          >
            <p className="text-xs font-body uppercase tracking-[0.2em] text-primary mb-2">
              Selected Work
            </p>
            <h2 className="font-display text-4xl font-bold text-foreground">
              Results that speak.
            </h2>
          </motion.div>

          <div
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5"
            data-ocid="project-grid"
          >
            {PROJECTS.map((project, i) => (
              <ProjectCard key={project.title} project={project} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* ── About ─────────────────────────────────────────────────── */}
      <section id="about" className="bg-background">
        <div className="max-w-5xl mx-auto px-6 py-24 grid lg:grid-cols-2 gap-16 items-start">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <p className="text-xs font-body uppercase tracking-[0.2em] text-primary mb-2">
              About
            </p>
            <h2 className="font-display text-4xl font-bold text-foreground mb-6">
              The writer behind the results.
            </h2>
            <p className="font-body text-muted-foreground leading-relaxed mb-4">
              I'm an email copywriter and marketing strategist who helps brands
              connect with their audience — and convert them. I believe great
              email copy feels like a conversation, not a broadcast.
            </p>
            <p className="font-body text-muted-foreground leading-relaxed">
              I combine strategic storytelling with conversion-focused
              psychology to write emails that feel personal at scale. Whether
              you need a full nurture sequence or a single high-stakes send, I
              bring the same rigour to every word.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <p className="text-xs font-body uppercase tracking-[0.2em] text-muted-foreground mb-5">
              Core Skills
            </p>
            <ul
              className="grid grid-cols-1 sm:grid-cols-2 gap-3"
              data-ocid="skills-list"
            >
              {SKILLS.map((skill, i) => (
                <motion.li
                  key={skill}
                  initial={{ opacity: 0, y: 8 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.07 }}
                  className="flex items-center gap-2.5 font-body text-sm text-foreground"
                >
                  <CheckCircle2
                    size={15}
                    className="text-accent flex-shrink-0"
                  />
                  {skill}
                </motion.li>
              ))}
            </ul>
          </motion.div>
        </div>
      </section>

      {/* ── Contact ───────────────────────────────────────────────── */}
      <section id="contact" className="bg-card border-t border-border">
        <div className="max-w-5xl mx-auto px-6 py-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="max-w-xl mx-auto flex flex-col items-center gap-6"
          >
            <p className="text-xs font-body uppercase tracking-[0.2em] text-primary">
              Get in touch
            </p>
            <h2 className="font-display text-4xl font-bold text-foreground leading-tight">
              Let's talk about your next campaign.
            </h2>
            <p className="font-body text-muted-foreground">
              Currently available for new projects. Drop me a line and I'll get
              back to you within 24 hours.
            </p>
            <a
              href="mailto:hello@yourname.com"
              data-ocid="contact-email"
              className="inline-flex items-center gap-2.5 bg-primary text-primary-foreground font-body text-sm px-8 py-3.5 rounded-md hover:opacity-90 transition-smooth shadow-card"
            >
              <Mail size={16} />
              hello@yourname.com
            </a>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
