import { motion } from "motion/react";

export interface Project {
  title: string;
  category: string;
  description: string;
  metric: string;
  metricLabel: string;
}

interface ProjectCardProps {
  project: Project;
  index: number;
}

export function ProjectCard({ project, index }: ProjectCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      data-ocid={`project-card-${index}`}
      className="group bg-card border border-border rounded-lg p-6 flex flex-col gap-4 hover:shadow-elevated transition-smooth cursor-default"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-body uppercase tracking-widest text-muted-foreground mb-1">
            {project.category}
          </p>
          <h3 className="font-display text-lg font-semibold text-foreground leading-snug">
            {project.title}
          </h3>
        </div>
      </div>

      <p className="text-sm font-body text-muted-foreground leading-relaxed flex-1">
        {project.description}
      </p>

      <div className="flex items-baseline gap-2 pt-2 border-t border-border">
        <span className="font-display text-2xl font-bold text-primary">
          {project.metric}
        </span>
        <span className="text-xs font-body text-muted-foreground uppercase tracking-wide">
          {project.metricLabel}
        </span>
      </div>
    </motion.div>
  );
}
